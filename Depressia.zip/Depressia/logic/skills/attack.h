#pragma once

#ifndef ATTACK_H
#define ATTACK_H

#include "logic/skills/skill.h"

class Skill;
class Entity;

class Attack : public Skill
{
public:
    Attack();
    Attack(std::string n, std::string t, int mp, Range rng, double c);
    ~Attack();

    int call(Entity& user, Entity& target);
    std::vector<int> call(Entity& user, std::vector<Entity> targets);

private:
    double coef;
    int effect(Entity& user, Entity& target, float coef);
    void setSummary(HitEffect he, std::string user, std::string target, int deg);
    void setSummary(HitEffect he, std::string user, std::vector<std::string> target, std::vector<int>);

};

#endif // ATTACK_H
