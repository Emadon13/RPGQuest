#include "finalscreen.h"

FinalScreen::FinalScreen()
{

}
