#ifndef SAVE_H
#define SAVE_H

#include "logic/events/event.h"


class Save : public Event
{
public:
    Save();
};

#endif // SAVE_H
