#ifndef FIGHT_H
#define FIGHT_H

#include<array>
#include"logic/entities/entity.h"



class Fight
{
public:
    Fight();

    /*
    Fight(Entity* o[]);

    Entity** getHeroes();
    Entity** getOppenents();
    Entity** getAll_e();




private:

    static const int nb_e = 2;
    Entity* heroes[nb_e];
    Entity* opponents[nb_e];
    Entity* all_e[2*nb_e];


    void setOrder(std::vector <Entity> fighters);

    */
};

#endif // FIGHT_H
