#include "event.h"

using namespace std;

Event::Event()
{

}


Event::~Event()
{

}
