#include "fight.h"

Fight::Fight()
{

}
/*
Fight::Fight(vector<Entity> h, vector<Entity> o):
    heroes(nb_e),
    opponents(nb_e),
    all_e(2*nb_e)
{
    heroes = h;
    opponents = o;
    vector<Entity> concat = h;
    concat.insert( concat.end(), o.begin(), o.end() );
    all_e = concat;

}

vector<Entity> Fight::getHeroes()
{
    return heroes;
}
*/
