#ifndef FINALSCREEN_H
#define FINALSCREEN_H

#include "logic/events/event.h"


class FinalScreen : public Event
{
public:
    FinalScreen();
};

#endif // FINALSCREEN_H
