#ifndef EVENT_H
#define EVENT_H



class Event
{
public:
    Event();
    virtual ~Event();

};

#endif // EVENT_H
