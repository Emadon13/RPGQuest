#ifndef ENEMY_H
#define ENEMY_H

#include "logic/entities/entity.h"

class Enemy : public Entity
{
public:
    Enemy();
};

#endif // ENEMY_H
