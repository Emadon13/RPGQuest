#include "hero.h"

using namespace std;

Hero::Hero():
    xp(0),
    base_hp(100),
    base_mp(20),
    base_att(10),
    base_def(10),
    base_spd(10)

{
    Entity("toto",
           1,
           int(base_hp*(lvl/max_lvl)),
           int(base_mp*(lvl/max_lvl)),
           int(base_att*(lvl/max_lvl)),
           int(base_def*(lvl/max_lvl)),
           int(base_spd*(lvl/max_lvl)),
           vector<Skill*>(0));

    calculateNextLevel();

}

Hero::Hero(string n,
           int l,
           int b_hp,
           int b_mp,
           int b_att,
           int b_def,
           int b_spd,
           vector<Skill*> s,
           string stl[max_lvl]):
    xp(0),
    base_hp(b_hp),
    base_mp(b_mp),
    base_att(b_att),
    base_def(b_def),
    base_spd(b_spd)

{

    for(int i=0 ; i<max_lvl ; i++)
        skillsToLearn[i] = stl[i];

    Entity(n,
           l,
           int(base_hp*(lvl/max_lvl)),
           int(base_mp*(lvl/max_lvl)),
           int(base_att*(lvl/max_lvl)),
           int(base_def*(lvl/max_lvl)),
           int(base_spd*(lvl/max_lvl)),
           vector<Skill*>(s));

    calculateNextLevel();

}




void Hero::calculateNextLevel()
{
    next_level = lvl*lvl*10;
}

