#include "team.h"

Team::Team():
    h1()
{

}
