#include "enemy.h"

Enemy::Enemy():
    Entity()
{

}
