#ifndef STAGE_H
#define STAGE_H


class Stage
{
public:
    Stage();
};

#endif // STAGE_H