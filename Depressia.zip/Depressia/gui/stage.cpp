#include "stage.h"

Stage::Stage()
{

}
